<?php
the_content();
?>